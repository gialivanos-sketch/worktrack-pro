# ⏱ WorkTrack PRO

Σύστημα διαχείρισης παρουσιών και μισθοδοσίας — με Firebase Firestore για συγχρονισμό σε πραγματικό χρόνο.

---

## 🚀 Ανέβασμα στο Vercel (δωρεάν, ~10 λεπτά)

### Βήμα 1 — Δημιούργησε λογαριασμό GitHub
Πήγαινε στο https://github.com και κάνε εγγραφή (δωρεάν).

### Βήμα 2 — Ανέβασε τα αρχεία
1. Στο GitHub, πάτα **"New repository"**
2. Όνομα: `worktrack-pro`, επέλεξε **Public**
3. Πάτα **"uploading an existing file"**
4. Σύρε όλα τα αρχεία του φακέλου εδώ (index.html, vite.config.js, package.json, README.md + φάκελο src/)
5. Πάτα **"Commit changes"**

### Βήμα 3 — Σύνδεσε με Vercel
1. Πήγαινε στο https://vercel.com → **Sign up with GitHub**
2. Πάτα **"Add New Project"**
3. Επέλεξε το repository `worktrack-pro`
4. Πάτα **Deploy** (χωρίς άλλες ρυθμίσεις)
5. Σε ~1 λεπτό παίρνεις URL: `worktrack-pro.vercel.app`

### Βήμα 4 — Firebase rules (ΣΗΜΑΝΤΙΚΟ)
Στο Firebase Console → Firestore → Rules, βάλε:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /worktrack/{document} {
      allow read, write: if true;
    }
  }
}
```
Αυτό επιτρέπει πρόσβαση μόνο στη συλλογή worktrack.

---

## 🔐 Αλλαγή PIN
Στο `src/App.jsx`, βρες:
```js
const ADMIN_PIN = "1234";
```
Άλλαξέ το πριν ανεβάσεις στο GitHub.

---

## 💻 Τοπική δοκιμή
```bash
npm install
npm run dev
```
