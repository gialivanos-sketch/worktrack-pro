import React, { useState, useEffect, useCallback } from "react";
import * as XLSXLib from "xlsx";
import { initializeApp } from "firebase/app";
import { getFirestore, doc, getDoc, setDoc } from "firebase/firestore";

// ─── FIREBASE CONFIG ──────────────────────────────────────────────────────────
const firebaseConfig = {
  apiKey: "AIzaSyA6eI-yiFdB1VM9DbYvaIumYtL8KtmOzug",
  authDomain: "worktrack-pro-be027.firebaseapp.com",
  databaseURL: "https://worktrack-pro-be027-default-rtdb.firebaseio.com",
  projectId: "worktrack-pro-be027",
  storageBucket: "worktrack-pro-be027.firebasestorage.app",
  messagingSenderId: "1036336932676",
  appId: "1:1036336932676:web:1d33cab3c507c9578c5911"
};

const firebaseApp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseApp);

async function loadSheetJS() { return XLSXLib; }

// ─── STORAGE (Firestore) ──────────────────────────────────────────────────────
async function loadData(key) {
  try {
    const ref = doc(db, "worktrack", key);
    const snap = await getDoc(ref);
    return snap.exists() ? snap.data().value : null;
  } catch (e) { console.error("loadData error", e); return null; }
}
async function saveData(key, val) {
  try {
    const ref = doc(db, "worktrack", key);
    await setDoc(ref, { value: val });
  } catch (e) { console.error("saveData error", e); }
}

// ─── UTILS ────────────────────────────────────────────────────────────────────
const fmtTime   = iso => new Date(iso).toLocaleTimeString("el-GR", { hour:"2-digit", minute:"2-digit" });
const fmtDate   = iso => new Date(iso).toLocaleDateString("el-GR");
const fmtDateISO = d  => d.toISOString().slice(0,10);
const fmtDur    = ms  => { const h=Math.floor(ms/3600000),m=Math.floor((ms%3600000)/60000); return `${h}ω ${m}λ`; };
const fmtHours  = ms  => +(ms/3600000).toFixed(2);
const DAYS_GR   = ["Δευ","Τρι","Τετ","Πεμ","Παρ","Σαβ","Κυρ"];
const MONTHS_GR = ["Ιανουάριος","Φεβρουάριος","Μάρτιος","Απρίλιος","Μάιος","Ιούνιος","Ιούλιος","Αύγουστος","Σεπτέμβριος","Οκτώβριος","Νοέμβριος","Δεκέμβριος"];
const genId     = () => Math.random().toString(36).slice(2,9);
const ADMIN_PIN = "1234";

function stringToColor(s="") {
  let h=0; for(let i=0;i<s.length;i++) h=s.charCodeAt(i)+((h<<5)-h);
  return `hsl(${Math.abs(h)%360},55%,42%)`;
}

// ─── PAYROLL CALC ─────────────────────────────────────────────────────────────
function calcPayroll(emp, records, year, month) {
  const monthRecs = records.filter(r => {
    const d = new Date(r.checkIn);
    return r.empId===emp.id && d.getFullYear()===year && d.getMonth()===month && r.checkOut;
  });

  let regularMs=0, overtimeMs=0;
  const dailyMap = {};

  monthRecs.forEach(r => {
    const dateKey = fmtDateISO(new Date(r.checkIn));
    const ms = new Date(r.checkOut)-new Date(r.checkIn);
    dailyMap[dateKey] = (dailyMap[dateKey]||0) + ms;
  });

  const otThreshMs = (emp.overtimeAfter||8) * 3600000;
  Object.values(dailyMap).forEach(dayMs => {
    if(dayMs > otThreshMs) {
      regularMs += otThreshMs;
      overtimeMs += dayMs - otThreshMs;
    } else {
      regularMs += dayMs;
    }
  });

  const regularHours = fmtHours(regularMs);
  const overtimeHours = fmtHours(overtimeMs);
  const totalHours = regularHours + overtimeHours;
  const workingDays = Object.keys(dailyMap).length;

  // Το καταχωρημένο ποσό = ΣΥΜΦΩΝΙΑ (καθαρό που παίρνει ο υπάλληλος)
  // Αντίστροφος υπολογισμός: Μικτό = Καθαρό / (1 - ΙΚΑ_εργαζ%)
  const ikaEmpRate = (parseFloat(emp.ikaEmployee)||16) / 100;
  const ikaErRate  = (parseFloat(emp.ikaEmployer)||24.81) / 100;
  const agreedNet  = parseFloat(emp.salary)||0;

  let grossSalary = 0;
  if (emp.salaryType==="hourly") {
    const netRate     = agreedNet;
    const grossRate   = netRate / (1 - ikaEmpRate);
    const otGrossRate = grossRate * (1 + (parseFloat(emp.overtimeRate)||0.5));
    grossSalary = regularHours*grossRate + overtimeHours*otGrossRate;
  } else if (emp.salaryType==="daily") {
    const dailyGross = agreedNet / (1 - ikaEmpRate);
    grossSalary = workingDays * dailyGross;
  } else {
    const agreedGross  = agreedNet / (1 - ikaEmpRate);
    const dailyRate    = agreedGross / (emp.monthlyDays||25);
    const hourlyRate   = dailyRate / (parseFloat(emp.expectedHoursPerDay)||8);
    const otGrossRate  = hourlyRate * (1+(parseFloat(emp.overtimeRate)||0.5));
    grossSalary = agreedGross + overtimeHours*otGrossRate;
  }

  const ikaEmployee = grossSalary * ikaEmpRate;
  const ikaEmployer = grossSalary * ikaErRate;
  const netSalary   = grossSalary - ikaEmployee;

  return { regularHours, overtimeHours, totalHours, workingDays, agreedNet, grossSalary, ikaEmployee, ikaEmployer, netSalary, dailyMap, monthRecs };
}

// ─── APP ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [view, setView]           = useState("loading");
  const [employeeId, setEmployeeId] = useState(null);
  const [employees, setEmployees] = useState([]);
  const [records, setRecords]     = useState([]);
  const [pin, setPin]             = useState("");
  const [pinErr, setPinErr]       = useState(false);

  useEffect(() => {
    const p = new URLSearchParams(window.location.search).get("emp");
    if(p) { setEmployeeId(p); setView("employee"); } else setView("pin");
  }, []);

  useEffect(() => {
    (async () => {
      setEmployees(await loadData("emps")||[]);
      setRecords(await loadData("recs")||[]);
    })();
  }, []);

  const persistEmp = useCallback(async d => { setEmployees(d); await saveData("emps",d); },[]);
  const persistRec = useCallback(async d => { setRecords(d);   await saveData("recs",d); },[]);

  const handlePin = () => { if(pin===ADMIN_PIN){setView("admin");setPinErr(false);}else{setPinErr(true);setPin("");} };

  if(view==="loading") return <div style={S.center}><Spinner/></div>;
  if(view==="pin")      return <PinScreen pin={pin} setPin={setPin} onSubmit={handlePin} err={pinErr}/>;
  if(view==="employee") return <EmployeeView employeeId={employeeId} employees={employees} records={records} persistRecords={persistRec}/>;
  return <AdminPanel employees={employees} persistEmployees={persistEmp} records={records} persistRecords={persistRec}/>;
}

// ─── PIN ──────────────────────────────────────────────────────────────────────
function PinScreen({pin,setPin,onSubmit,err}) {
  return (
    <div style={S.pinWrap}>
      <div style={S.pinCard}>
        <div style={{fontSize:52,marginBottom:8}}>⏱</div>
        <h2 style={S.pinTitle}>WorkTrack <span style={{color:"#60a5fa",fontSize:16,fontWeight:400}}>PRO</span></h2>
        <p style={S.pinSub}>Σύστημα Διαχείρισης Προσωπικού</p>
        <input style={{...S.pinInput,...(err?{borderColor:"#ef4444"}:{})}}
          type="password" placeholder="PIN διαχειριστή" value={pin}
          onChange={e=>setPin(e.target.value)} onKeyDown={e=>e.key==="Enter"&&onSubmit()} maxLength={8}/>
        {err && <p style={{color:"#ef4444",fontSize:13,margin:"4px 0"}}>Λάθος PIN</p>}
        <button style={S.pinBtn} onClick={onSubmit}>ΕΙΣΟΔΟΣ</button>
        <p style={{color:"#475569",fontSize:12,marginTop:16}}>Demo PIN: 1234</p>
      </div>
    </div>
  );
}

// ─── ADMIN ────────────────────────────────────────────────────────────────────
function AdminPanel({employees,persistEmployees,records,persistRecords}) {
  const [tab,setTab] = useState("dashboard");
  const tabs = [["dashboard","📊","Dashboard"],["employees","👥","Υπάλληλοι"],["records","📋","Αρχείο"],["payroll","💰","Μισθοδοσία"],["links","📲","Links & Αποστολή"]];
  return (
    <div style={S.wrap}>
      <header style={S.header}>
        <span style={S.hLogo}>⏱ WorkTrack <b style={{color:"#60a5fa"}}>PRO</b></span>
        <nav style={S.nav}>
          {tabs.map(([k,ic,lb])=>(
            <button key={k} style={{...S.navBtn,...(tab===k?S.navActive:{})}} onClick={()=>setTab(k)}>
              {ic} {lb}
            </button>
          ))}
        </nav>
      </header>
      <main style={S.main}>
        {tab==="dashboard" && <Dashboard employees={employees} records={records}/>}
        {tab==="employees" && <EmployeesTab employees={employees} persistEmployees={persistEmployees} records={records}/>}
        {tab==="records"   && <RecordsTab employees={employees} records={records} persistRecords={persistRecords}/>}
        {tab==="payroll"   && <PayrollTab employees={employees} records={records}/>}
        {tab==="links"     && <LinksTab employees={employees}/>}
      </main>
    </div>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function Dashboard({employees,records}) {
  const todayStr = new Date().toDateString();
  const todayRecs = records.filter(r=>new Date(r.checkIn).toDateString()===todayStr);
  const activeNow = todayRecs.filter(r=>!r.checkOut);
  const totalToday = todayRecs.filter(r=>r.checkOut).reduce((a,r)=>a+(new Date(r.checkOut)-new Date(r.checkIn)),0);
  const now2 = new Date(), startW=new Date(now2); startW.setDate(now2.getDate()-((now2.getDay()+6)%7)); startW.setHours(0,0,0,0);
  const weekMs = records.filter(r=>new Date(r.checkIn)>=startW&&r.checkOut).reduce((a,r)=>a+(new Date(r.checkOut)-new Date(r.checkIn)),0);

  return (
    <div>
      <h2 style={S.pageTitle}>Dashboard</h2>
      <p style={S.pageSub}>{new Date().toLocaleDateString("el-GR",{weekday:"long",day:"numeric",month:"long",year:"numeric"})}</p>
      <div style={S.statsGrid}>
        <StatCard icon="👥" label="Υπάλληλοι" value={employees.length} color="#3b82f6"/>
        <StatCard icon="✅" label="Παρόντες" value={activeNow.length} color="#10b981"/>
        <StatCard icon="⏰" label="Ώρες Σήμερα" value={fmtDur(totalToday)} color="#f59e0b"/>
        <StatCard icon="📅" label="Ώρες Εβδομάδας" value={fmtDur(weekMs)} color="#8b5cf6"/>
      </div>

      <h3 style={S.sectionTitle}>Παρόντες Τώρα</h3>
      {activeNow.length===0 ? <Empty text="Κανείς δεν είναι παρών αυτή τη στιγμή"/> :
        <Table cols={["Υπάλληλος","Είσοδος","Διάρκεια"]}>
          {activeNow.map(r=>{
            const emp=employees.find(e=>e.id===r.empId);
            return <TR key={r.id}><TD><span style={S.greenDot}/>  {emp?`${emp.firstName} ${emp.lastName}`:"—"}</TD><TD>{fmtTime(r.checkIn)}</TD><TD>{fmtDur(Date.now()-new Date(r.checkIn))}</TD></TR>;
          })}
        </Table>}

      <h3 style={S.sectionTitle}>Σημερινές Κινήσεις</h3>
      {todayRecs.filter(r=>r.checkOut).length===0 ? <Empty text="Δεν υπάρχουν ολοκληρωμένες εγγραφές σήμερα"/> :
        <Table cols={["Υπάλληλος","Είσοδος","Έξοδος","Ώρες"]}>
          {todayRecs.filter(r=>r.checkOut).map(r=>{
            const emp=employees.find(e=>e.id===r.empId);
            return <TR key={r.id}><TD>{emp?`${emp.firstName} ${emp.lastName}`:"—"}</TD><TD>{fmtTime(r.checkIn)}</TD><TD>{fmtTime(r.checkOut)}</TD><TD><b>{fmtDur(new Date(r.checkOut)-new Date(r.checkIn))}</b></TD></TR>;
          })}
        </Table>}
    </div>
  );
}

function StatCard({icon,label,value,color}) {
  return <div style={{...S.statCard,borderTop:`3px solid ${color}`}}><span style={{fontSize:28}}>{icon}</span><div><div style={{...S.statVal,color}}>{value}</div><div style={S.statLabel}>{label}</div></div></div>;
}

// ─── EMPLOYEES TAB ────────────────────────────────────────────────────────────
const EMP_EMPTY = {firstName:"",lastName:"",phone:"",salary:"",salaryType:"monthly",days:[0,1,2,3,4],startTime:"09:00",endTime:"17:00",
  overtimeAfter:"8",overtimeRate:"0.5",expectedHoursPerDay:"8",monthlyDays:"25",
  ikaEmployee:"16",ikaEmployer:"24.81",notes:"",status:"active"};

// Modal για επιβεβαίωση ενεργειών
function ConfirmModal({open,title,message,color,confirmLabel,onConfirm,onCancel,extra}) {
  if(!open) return null;
  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.5)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:1000}}>
      <div style={{background:"#fff",borderRadius:16,padding:28,width:380,boxShadow:"0 20px 60px rgba(0,0,0,0.3)"}}>
        <h3 style={{margin:"0 0 10px",color:"#0f172a",fontSize:18}}>{title}</h3>
        <p style={{margin:"0 0 16px",color:"#64748b",fontSize:14,lineHeight:1.5}}>{message}</p>
        {extra}
        <div style={{display:"flex",gap:10,marginTop:8}}>
          <button style={{...S.btnPrimary,background:color||"#ef4444",flex:1}} onClick={onConfirm}>{confirmLabel}</button>
          <button style={{...S.btnSec,flex:1}} onClick={onCancel}>Ακύρωση</button>
        </div>
      </div>
    </div>
  );
}

function EmployeesTab({employees,persistEmployees,records}) {
  const [form,setForm]     = useState(EMP_EMPTY);
  const [editing,setEd]    = useState(null);
  const [showForm,setSF]   = useState(false);
  const [filter,setFilter] = useState("active"); // active | inactive | all
  const [modal,setModal]   = useState(null); // {type:"delete"|"resign"|"terminate", emp, reason:"", date:""}

  const save = async()=>{
    if(!form.firstName||!form.lastName) return alert("Συμπληρώστε όνομα και επίθετο.");
    if(editing) await persistEmployees(employees.map(e=>e.id===editing?{...form,id:editing}:e));
    else        await persistEmployees([...employees,{...form,id:genId(),createdAt:new Date().toISOString(),status:"active"}]);
    setForm(EMP_EMPTY); setEd(null); setSF(false);
  };
  const edit = emp=>{ setForm({...EMP_EMPTY,...emp}); setEd(emp.id); setSF(true); };
  const toggleDay = d => setForm(f=>({...f,days:f.days.includes(d)?f.days.filter(x=>x!==d):[...f.days,d]}));
  const F = (l,k,t="text")=><div><label style={S.label}>{l}</label><input style={S.input} type={t} value={form[k]||""} onChange={e=>setForm(f=>({...f,[k]:e.target.value}))}/></div>;

  // Εκτέλεση modal action
  const doAction = async()=>{
    const {type,emp} = modal;
    if(type==="delete") {
      await persistEmployees(employees.filter(e=>e.id!==emp.id));
    } else if(type==="resign") {
      await persistEmployees(employees.map(e=>e.id===emp.id?{...e,status:"resigned",resignedAt:modal.date||new Date().toISOString().slice(0,10),resignReason:modal.reason}:e));
    } else if(type==="terminate") {
      await persistEmployees(employees.map(e=>e.id===emp.id?{...e,status:"terminated",terminatedAt:modal.date||new Date().toISOString().slice(0,10),terminateReason:modal.reason}:e));
    } else if(type==="reactivate") {
      await persistEmployees(employees.map(e=>e.id===emp.id?{...e,status:"active",resignedAt:null,terminatedAt:null,resignReason:"",terminateReason:""}:e));
    }
    setModal(null);
  };

  const filtered = employees.filter(e=>
    filter==="all" ? true :
    filter==="active" ? e.status==="active" :
    e.status==="resigned"||e.status==="terminated"
  );

  const activeCount   = employees.filter(e=>e.status==="active").length;
  const inactiveCount = employees.filter(e=>e.status!=="active").length;

  const modalConfig = modal ? {
    delete:     {title:"🗑️ Διαγραφή Υπαλλήλου",message:`Η διαγραφή του "${modal.emp?.firstName} ${modal.emp?.lastName}" είναι μόνιμη. Θα διαγραφούν και όλες οι καταχωρήσεις παρουσίας. Είστε σίγουρος;`,color:"#ef4444",confirmLabel:"Διαγραφή"},
    resign:     {title:"📋 Παραίτηση",message:`Καταχώρηση παραίτησης για τον/την "${modal.emp?.firstName} ${modal.emp?.lastName}". Ο υπάλληλος δεν θα μπορεί να κάνει είσοδο/έξοδο.`,color:"#f59e0b",confirmLabel:"Καταχώρηση Παραίτησης"},
    terminate:  {title:"🔒 Κλείσιμο Σύμβασης",message:`Κλείσιμο σύμβασης για τον/την "${modal.emp?.firstName} ${modal.emp?.lastName}". Ο υπάλληλος δεν θα μπορεί να κάνει είσοδο/έξοδο.`,color:"#dc2626",confirmLabel:"Κλείσιμο Σύμβασης"},
    reactivate: {title:"✅ Επανενεργοποίηση",message:`Επανενεργοποίηση του/της "${modal.emp?.firstName} ${modal.emp?.lastName}";`,color:"#10b981",confirmLabel:"Επανενεργοποίηση"},
  }[modal.type] : null;

  return (
    <div>
      {/* Confirm Modal */}
      <ConfirmModal
        open={!!modal}
        title={modalConfig?.title}
        message={modalConfig?.message}
        color={modalConfig?.color}
        confirmLabel={modalConfig?.confirmLabel}
        onConfirm={doAction}
        onCancel={()=>setModal(null)}
        extra={modal&&(modal.type==="resign"||modal.type==="terminate")?(
          <div style={{display:"flex",flexDirection:"column",gap:10,marginBottom:8}}>
            <div>
              <label style={S.label}>Ημερομηνία</label>
              <input style={S.input} type="date" value={modal.date||new Date().toISOString().slice(0,10)}
                onChange={e=>setModal(m=>({...m,date:e.target.value}))}/>
            </div>
            <div>
              <label style={S.label}>Αιτία (προαιρετικό)</label>
              <input style={S.input} type="text" placeholder="π.χ. Προσωπικοί λόγοι..."
                value={modal.reason||""} onChange={e=>setModal(m=>({...m,reason:e.target.value}))}/>
            </div>
          </div>
        ):null}
      />

      <div style={S.rowBetween}>
        <div>
          <h2 style={S.pageTitle}>Υπάλληλοι</h2>
          <div style={{display:"flex",gap:8,marginTop:8}}>
            {[["active",`✅ Ενεργοί (${activeCount})`],["inactive",`🔒 Αδρανείς (${inactiveCount})`],["all","👥 Όλοι"]].map(([v,l])=>(
              <button key={v} style={{...S.filterBtn,...(filter===v?S.filterBtnActive:{})}} onClick={()=>setFilter(v)}>{l}</button>
            ))}
          </div>
        </div>
        <button style={S.btnPrimary} onClick={()=>{setForm(EMP_EMPTY);setEd(null);setSF(true);}}>+ Νέος Υπάλληλος</button>
      </div>

      {showForm && (
        <div style={S.formCard}>
          <h3 style={S.formTitle}>{editing?"✏️ Επεξεργασία":"➕ Νέος Υπάλληλος"}</h3>
          <SectionLabel>Στοιχεία</SectionLabel>
          <div style={S.grid2}>{F("Όνομα *","firstName")}{F("Επίθετο *","lastName")}{F("Τηλέφωνο","phone","tel")}</div>
          <SectionLabel>Αμοιβή</SectionLabel>
          <div style={S.grid2}>
            <div>
              <label style={S.label}>Ποσό (€)</label>
              <div style={{display:"flex",gap:8}}>
                <input style={{...S.input,flex:1}} type="number" value={form.salary} onChange={e=>setForm(f=>({...f,salary:e.target.value}))}/>
                <select style={{...S.input,width:120}} value={form.salaryType} onChange={e=>setForm(f=>({...f,salaryType:e.target.value}))}>
                  <option value="monthly">/ μήνα</option><option value="daily">/ ημέρα</option><option value="hourly">/ ώρα</option>
                </select>
              </div>
            </div>
            {F("Αναμ. ώρες/ημέρα","expectedHoursPerDay","number")}
            {F("Εργάσιμες ημέρες/μήνα","monthlyDays","number")}
          </div>
          <SectionLabel>Υπερωρίες</SectionLabel>
          <div style={S.grid2}>
            {F("Υπερωρία μετά από (ώρες/ημέρα)","overtimeAfter","number")}
            <div>
              <label style={S.label}>Αποζημίωση υπερωρίας</label>
              <select style={S.input} value={form.overtimeRate} onChange={e=>setForm(f=>({...f,overtimeRate:e.target.value}))}>
                <option value="0.25">+25%</option><option value="0.5">+50% (κανονική)</option>
                <option value="0.75">+75%</option><option value="1.0">+100% (διπλή)</option>
              </select>
            </div>
          </div>
          <SectionLabel>ΙΚΑ / Ασφαλιστικές Εισφορές</SectionLabel>
          <div style={S.grid2}>
            <div>
              <label style={S.label}>Εισφορά Εργαζομένου (%)</label>
              <input style={S.input} type="number" step="0.01" value={form.ikaEmployee} onChange={e=>setForm(f=>({...f,ikaEmployee:e.target.value}))}/>
              <span style={{fontSize:11,color:"#94a3b8"}}>Τυπικά: 16%</span>
            </div>
            <div>
              <label style={S.label}>Εισφορά Εργοδότη (%)</label>
              <input style={S.input} type="number" step="0.01" value={form.ikaEmployer} onChange={e=>setForm(f=>({...f,ikaEmployer:e.target.value}))}/>
              <span style={{fontSize:11,color:"#94a3b8"}}>Τυπικά: 24.81%</span>
            </div>
          </div>
          <SectionLabel>Πρόγραμμα</SectionLabel>
          <label style={S.label}>Ημέρες Εργασίας</label>
          <div style={{display:"flex",gap:8,marginBottom:16,flexWrap:"wrap"}}>
            {DAYS_GR.map((d,i)=><button key={i} style={{...S.dayBtn,...(form.days.includes(i)?S.dayActive:{})}} onClick={()=>toggleDay(i)}>{d}</button>)}
          </div>
          <div style={S.grid2}>{F("Ώρα Εισόδου","startTime","time")}{F("Ώρα Εξόδου","endTime","time")}</div>
          {F("Σημειώσεις","notes")}
          <div style={{display:"flex",gap:10,marginTop:12}}>
            <button style={S.btnPrimary} onClick={save}>{editing?"💾 Αποθήκευση":"✅ Καταχώρηση"}</button>
            <button style={S.btnSec} onClick={()=>{setSF(false);setEd(null);setForm(EMP_EMPTY);}}>Ακύρωση</button>
          </div>
        </div>
      )}

      {filtered.length===0 ? <Empty text="Δεν υπάρχουν υπάλληλοι σε αυτή την κατηγορία."/> :
        <div style={S.tableWrap}>
          <table style={S.table}><thead><tr style={S.thead}><TH>Ονοματεπώνυμο</TH><TH>Κατάσταση</TH><TH>Πρόγραμμα</TH><TH>Αμοιβή</TH><TH>Ενέργειες</TH></tr></thead>
            <tbody>{filtered.map(emp=>{
              const isPresent=records.some(r=>r.empId===emp.id&&!r.checkOut&&new Date(r.checkIn).toDateString()===new Date().toDateString());
              const isInactive=emp.status==="resigned"||emp.status==="terminated";
              return (
                <tr key={emp.id} style={{...S.tr,...(isInactive?{opacity:0.6,background:"#fafafa"}:{})}}>
                  <TD><div style={{display:"flex",alignItems:"center",gap:10}}>
                    <div style={{...S.avatar,background:isInactive?"#94a3b8":stringToColor(emp.firstName)}}>{emp.firstName[0]}{emp.lastName[0]}</div>
                    <div>
                      <div style={{fontWeight:700}}>{emp.firstName} {emp.lastName}</div>
                      <div style={{fontSize:12,color:"#94a3b8"}}>{emp.phone}</div>
                      {emp.status==="resigned"&&<div style={{fontSize:11,color:"#f59e0b"}}>Παραίτηση: {emp.resignedAt}{emp.resignReason?` · ${emp.resignReason}`:""}</div>}
                      {emp.status==="terminated"&&<div style={{fontSize:11,color:"#ef4444"}}>Λήξη: {emp.terminatedAt}{emp.terminateReason?` · ${emp.terminateReason}`:""}</div>}
                    </div>
                    {isPresent&&<span style={S.badge}>● Παρών</span>}
                  </div></TD>
                  <TD>
                    {emp.status==="active"&&<span style={{...S.statusBadge,background:"#dcfce7",color:"#15803d"}}>✅ Ενεργός</span>}
                    {emp.status==="resigned"&&<span style={{...S.statusBadge,background:"#fef3c7",color:"#92400e"}}>📋 Παραίτηση</span>}
                    {emp.status==="terminated"&&<span style={{...S.statusBadge,background:"#fee2e2",color:"#991b1b"}}>🔒 Κλειστός</span>}
                  </TD>
                  <TD><div style={{fontSize:13}}>{emp.days.map(d=>DAYS_GR[d]).join(", ")}</div><div style={{fontSize:12,color:"#94a3b8"}}>{emp.startTime}–{emp.endTime}</div></TD>
                  <TD>{emp.salary?`${emp.salary}€ ${emp.salaryType==="monthly"?"/ μήνα":emp.salaryType==="daily"?"/ ημέρα":"/ ώρα"}`:"—"}</TD>
                  <TD>
                    <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>
                      {!isInactive&&<button style={{...S.actionBtn,color:"#3b82f6",background:"#eff6ff",borderRadius:6,padding:"5px 8px",fontSize:13,fontWeight:600,border:"none"}} onClick={()=>edit(emp)} title="Επεξεργασία">✏️ Επεξ.</button>}
                      {!isInactive&&<button style={{...S.actionBtn,color:"#f59e0b",background:"#fffbeb",borderRadius:6,padding:"5px 8px",fontSize:13,fontWeight:600,border:"none"}} onClick={()=>setModal({type:"resign",emp,reason:"",date:new Date().toISOString().slice(0,10)})} title="Παραίτηση">🚪 Παραίτ.</button>}
                      {!isInactive&&<button style={{...S.actionBtn,color:"#ef4444",background:"#fef2f2",borderRadius:6,padding:"5px 8px",fontSize:13,fontWeight:600,border:"none"}} onClick={()=>setModal({type:"terminate",emp,reason:"",date:new Date().toISOString().slice(0,10)})} title="Κλείσιμο Σύμβασης">🔒 Κλείσιμο</button>}
                      {isInactive&&<button style={{...S.actionBtn,color:"#10b981",background:"#f0fdf4",borderRadius:6,padding:"5px 8px",fontSize:13,fontWeight:600,border:"none"}} onClick={()=>setModal({type:"reactivate",emp})} title="Επανενεργοποίηση">🔓 Ενεργ.</button>}
                      <button style={{...S.actionBtn,color:"#dc2626",background:"#fef2f2",borderRadius:6,padding:"5px 8px",fontSize:13,fontWeight:600,border:"none"}} onClick={()=>setModal({type:"delete",emp})} title="Διαγραφή">🗑️ Διαγρ.</button>
                    </div>
                  </TD>
                </tr>);
            })}</tbody>
          </table>
        </div>}
    </div>
  );
}

// ─── RECORDS TAB ──────────────────────────────────────────────────────────────
function RecordsTab({employees,records,persistRecords}) {
  const [fEmp,setFE] = useState("all");
  const [fDate,setFD] = useState("");
  let filtered=[...records].sort((a,b)=>new Date(b.checkIn)-new Date(a.checkIn));
  if(fEmp!=="all") filtered=filtered.filter(r=>r.empId===fEmp);
  if(fDate) filtered=filtered.filter(r=>r.checkIn.startsWith(fDate));
  const totalMs=filtered.filter(r=>r.checkOut).reduce((a,r)=>a+(new Date(r.checkOut)-new Date(r.checkIn)),0);
  const delRec=async id=>{ if(!confirm("Διαγραφή;")) return; await persistRecords(records.filter(r=>r.id!==id)); };
  return (
    <div>
      <h2 style={S.pageTitle}>Αρχείο Παρουσιών</h2>
      <div style={{display:"flex",gap:10,marginBottom:20,flexWrap:"wrap",alignItems:"center"}}>
        <select style={{...S.input,width:210}} value={fEmp} onChange={e=>setFE(e.target.value)}>
          <option value="all">Όλοι οι υπάλληλοι</option>
          {employees.map(e=><option key={e.id} value={e.id}>{e.firstName} {e.lastName}</option>)}
        </select>
        <input style={{...S.input,width:160}} type="date" value={fDate} onChange={e=>setFD(e.target.value)}/>
        {(fEmp!=="all"||fDate)&&<button style={S.btnSec} onClick={()=>{setFE("all");setFD("");}}>✕ Καθαρισμός</button>}
        <span style={{marginLeft:"auto",fontSize:13,color:"#94a3b8"}}>{filtered.filter(r=>r.checkOut).length} εγγραφές · <b style={{color:"#1e293b"}}>{fmtDur(totalMs)}</b></span>
      </div>
      {filtered.length===0?<Empty text="Δεν βρέθηκαν εγγραφές"/>:
        <Table cols={["Υπάλληλος","Ημερομηνία","Είσοδος","Έξοδος","Ώρες",""]}>
          {filtered.map(r=>{
            const emp=employees.find(e=>e.id===r.empId);
            const dur=r.checkOut?new Date(r.checkOut)-new Date(r.checkIn):null;
            return <TR key={r.id}>
              <TD>{emp?`${emp.firstName} ${emp.lastName}`:"—"}</TD>
              <TD>{fmtDate(r.checkIn)}</TD>
              <TD>{fmtTime(r.checkIn)}</TD>
              <TD>{r.checkOut?fmtTime(r.checkOut):<span style={{color:"#10b981",fontWeight:600}}>● Παρών</span>}</TD>
              <TD>{dur?<b>{fmtDur(dur)}</b>:"—"}</TD>
              <TD><button style={S.iconBtn} onClick={()=>delRec(r.id)}>🗑️</button></TD>
            </TR>;
          })}
        </Table>}
    </div>
  );
}

// ─── PAYROLL TAB ──────────────────────────────────────────────────────────────
function PayrollTab({employees,records}) {
  const now2=new Date();
  const [year,setYear]   = useState(now2.getFullYear());
  const [month,setMonth] = useState(now2.getMonth());
  const [detail,setDetail] = useState(null);

  const payrolls = employees.map(emp=>({emp, data:calcPayroll(emp,records,year,month)}));
  const totGross = payrolls.reduce((a,p)=>a+p.data.grossSalary,0);
  const totIKAem = payrolls.reduce((a,p)=>a+p.data.ikaEmployee,0);
  const totIKAer = payrolls.reduce((a,p)=>a+p.data.ikaEmployer,0);
  const totNet   = payrolls.reduce((a,p)=>a+p.data.netSalary,0);
  const totCost  = totGross + payrolls.reduce((a,p)=>a+p.data.ikaEmployer,0);

  const exportExcel = () => exportToExcel(employees, records, year, month, payrolls);

  const yr=[];for(let y=now2.getFullYear()-2;y<=now2.getFullYear();y++) yr.push(y);

  return (
    <div>
      <div style={S.rowBetween}>
        <div>
          <h2 style={S.pageTitle}>Μισθοδοσία</h2>
          <p style={S.pageSub}>Μηνιαία Κατάσταση Αποδοχών</p>
        </div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          <select style={{...S.input,width:160}} value={month} onChange={e=>setMonth(+e.target.value)}>
            {MONTHS_GR.map((m,i)=><option key={i} value={i}>{m}</option>)}
          </select>
          <select style={{...S.input,width:90}} value={year} onChange={e=>setYear(+e.target.value)}>
            {yr.map(y=><option key={y} value={y}>{y}</option>)}
          </select>
          <button style={{...S.btnPrimary,background:"#10b981",display:"flex",alignItems:"center",gap:6}} onClick={exportExcel}>
            📥 Εξαγωγή Excel
          </button>
        </div>
      </div>

      <div style={{background:"#f0fdf4",border:"1px solid #86efac",borderRadius:12,padding:"14px 18px",marginBottom:16,fontSize:14,color:"#166534"}}>
        ✅ <b>Οι καταχωρημένες αμοιβές είναι καθαρές (συμφωνία).</b> Το σύστημα υπολογίζει αυτόματα μικτές αποδοχές και εισφορές ΙΚΑ.
      </div>
      <div style={S.statsGrid}>
        <StatCard icon="🤝" label="Συμφωνία (Καθαρά)" value={`${payrolls.reduce((a,p)=>a+p.data.agreedNet,0).toFixed(2)}€`} color="#10b981"/>
        <StatCard icon="📊" label="Μικτές Αποδοχές" value={`${totGross.toFixed(2)}€`} color="#3b82f6"/>
        <StatCard icon="🏛️" label="ΙΚΑ Εργαζομένων" value={`${totIKAem.toFixed(2)}€`} color="#ef4444"/>
        <StatCard icon="🏢" label="ΙΚΑ Εργοδότη" value={`${totIKAer.toFixed(2)}€`} color="#f59e0b"/>
      </div>
      <div style={{background:"#fef3c7",border:"1px solid #fcd34d",borderRadius:10,padding:"10px 16px",fontSize:14,color:"#78350f",marginBottom:20}}>
        💼 Συνολικό κόστος εργοδότη: <b>{totCost.toFixed(2)}€</b> (μικτές + ΙΚΑ εργοδότη)
      </div>

      {employees.length===0?<Empty text="Δεν υπάρχουν υπάλληλοι"/>:
        <div style={S.tableWrap}>
          <table style={S.table}>
            <thead><tr style={S.thead}>
              <TH>Υπάλληλος</TH><TH>Εργάσιμες μέρες</TH><TH>Κανονικές ώρες</TH><TH>Υπερωρίες</TH><TH>Συμφωνία (καθαρά)</TH><TH>Μικτές</TH><TH>ΙΚΑ Εργαζ.</TH><TH>ΙΚΑ Εργοδ.</TH><TH>Καθαρά (τελικά)</TH><TH></TH>
            </tr></thead>
            <tbody>
              {payrolls.map(({emp,data})=>(
                <tr key={emp.id} style={S.tr}>
                  <TD><div style={{display:"flex",alignItems:"center",gap:8}}>
                    <div style={{...S.avatar,background:stringToColor(emp.firstName)}}>{emp.firstName[0]}{emp.lastName[0]}</div>
                    <div><div style={{fontWeight:700}}>{emp.firstName} {emp.lastName}</div><div style={{fontSize:12,color:"#94a3b8"}}>{emp.salaryType==="monthly"?"Μισθωτός":emp.salaryType==="hourly"?"Ωρομίσθιος":"Ημερομίσθιος"}</div></div>
                  </div></TD>
                  <TD>{data.workingDays}</TD>
                  <TD>{data.regularHours.toFixed(1)}ω</TD>
                  <TD>{data.overtimeHours>0?<span style={{color:"#f59e0b",fontWeight:700}}>{data.overtimeHours.toFixed(1)}ω</span>:"—"}</TD>
                  <TD><b style={{color:"#10b981"}}>{data.agreedNet.toFixed(2)}€</b></TD>
                  <TD>{data.grossSalary.toFixed(2)}€</TD>
                  <TD style={{color:"#ef4444"}}>−{data.ikaEmployee.toFixed(2)}€</TD>
                  <TD style={{color:"#f59e0b"}}>{data.ikaEmployer.toFixed(2)}€</TD>
                  <TD><b style={{color:"#3b82f6"}}>{data.netSalary.toFixed(2)}€</b></TD>
                  <TD><button style={{...S.iconBtn,fontSize:13}} onClick={()=>setDetail(detail?.id===emp.id?null:{id:emp.id,emp,data})}>🔍</button></TD>
                </tr>
              ))}
              <tr style={{...S.tr,background:"#f1f5f9",fontWeight:700}}>
                <TD>ΣΥΝΟΛΟ</TD><TD>—</TD><TD>—</TD><TD>—</TD>
                <TD style={{color:"#10b981"}}>{payrolls.reduce((a,p)=>a+p.data.agreedNet,0).toFixed(2)}€</TD>
                <TD>{totGross.toFixed(2)}€</TD>
                <TD style={{color:"#ef4444"}}>−{totIKAem.toFixed(2)}€</TD>
                <TD style={{color:"#f59e0b"}}>{totIKAer.toFixed(2)}€</TD>
                <TD style={{color:"#3b82f6"}}>{totNet.toFixed(2)}€</TD>
                <TD></TD>
              </tr>
            </tbody>
          </table>
        </div>}

      {detail && (
        <div style={{...S.formCard,marginTop:20}}>
          <div style={S.rowBetween}>
            <h3 style={S.formTitle}>🔍 Ανάλυση: {detail.emp.firstName} {detail.emp.lastName}</h3>
            <button style={S.iconBtn} onClick={()=>setDetail(null)}>✕</button>
          </div>
          <div style={{overflowX:"auto"}}>
            <table style={{...S.table,fontSize:13}}>
              <thead><tr style={S.thead}><TH>Ημερομηνία</TH><TH>Είσοδος</TH><TH>Έξοδος</TH><TH>Κανονικές ώρες</TH><TH>Υπερωρίες</TH></tr></thead>
              <tbody>
                {Object.entries(detail.data.dailyMap).sort().map(([date,ms])=>{
                  const otMs=(detail.emp.overtimeAfter||8)*3600000;
                  const reg=Math.min(ms,otMs); const ot=Math.max(0,ms-otMs);
                  const dayRecs=detail.data.monthRecs.filter(r=>r.checkIn.startsWith(date));
                  return <tr key={date} style={S.tr}>
                    <TD>{new Date(date).toLocaleDateString("el-GR",{weekday:"short",day:"numeric",month:"short"})}</TD>
                    <TD>{dayRecs.length>0?fmtTime(dayRecs[0].checkIn):"—"}</TD>
                    <TD>{dayRecs.length>0&&dayRecs[dayRecs.length-1].checkOut?fmtTime(dayRecs[dayRecs.length-1].checkOut):"—"}</TD>
                    <TD>{fmtHours(reg).toFixed(2)}ω</TD>
                    <TD>{ot>0?<span style={{color:"#f59e0b",fontWeight:600}}>{fmtHours(ot).toFixed(2)}ω</span>:"—"}</TD>
                  </tr>;
                })}
              </tbody>
            </table>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:12,marginTop:16}}>
            {[["🤝 Συμφωνία (καθαρά)",`${detail.data.agreedNet.toFixed(2)}€`,"#10b981"],
              ["📊 Μικτές αποδοχές",`${detail.data.grossSalary.toFixed(2)}€`,"#3b82f6"],
              ["ΙΚΑ εργαζόμενου",`−${detail.data.ikaEmployee.toFixed(2)}€`,"#ef4444"],
              ["ΙΚΑ εργοδότη",`${detail.data.ikaEmployer.toFixed(2)}€`,"#f59e0b"],
              ["Κόστος εργοδότη",`${(detail.data.grossSalary+detail.data.ikaEmployer).toFixed(2)}€`,"#8b5cf6"]
            ].map(([l,v,c])=>(
              <div key={l} style={{background:"#f8fafc",borderRadius:10,padding:"12px 16px",borderLeft:`4px solid ${c}`}}>
                <div style={{fontSize:12,color:"#94a3b8"}}>{l}</div>
                <div style={{fontSize:20,fontWeight:800,color:c}}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── EXCEL EXPORT ─────────────────────────────────────────────────────────────
async function exportToExcel(employees, records, year, month, payrolls) {
  const XLSX = await loadSheetJS();
  const wb = XLSX.utils.book_new();
  const monthName = MONTHS_GR[month];

  // ── Sheet 1: Παρουσιολόγιο ────────────────────────────────────────────────
  const rows1 = [];
  rows1.push([`ΠΑΡΟΥΣΙΟΛΟΓΙΟ ${monthName} ${year}`]);
  rows1.push([]);
  rows1.push(["Υπάλληλος","Ημερομηνία","Ημέρα","Ώρα Εισόδου","Ώρα Εξόδου","Ώρες Εργασίας","Υπερωρίες"]);

  employees.forEach(emp => {
    const { monthRecs, dailyMap } = calcPayroll(emp, records, year, month);
    const otThresMs = (emp.overtimeAfter||8)*3600000;
    Object.entries(dailyMap).sort().forEach(([date,ms]) => {
      const dayRecs = monthRecs.filter(r=>r.checkIn.startsWith(date));
      const reg = Math.min(ms,otThresMs);
      const ot  = Math.max(0,ms-otThresMs);
      const d   = new Date(date);
      rows1.push([
        `${emp.firstName} ${emp.lastName}`,
        d.toLocaleDateString("el-GR"),
        ["Δευτέρα","Τρίτη","Τετάρτη","Πέμπτη","Παρασκευή","Σάββατο","Κυριακή"][(d.getDay()+6)%7],
        dayRecs[0]?fmtTime(dayRecs[0].checkIn):"—",
        dayRecs[dayRecs.length-1]?.checkOut?fmtTime(dayRecs[dayRecs.length-1].checkOut):"—",
        +fmtHours(reg).toFixed(2),
        +fmtHours(ot).toFixed(2),
      ]);
    });
    rows1.push([]);
  });

  const ws1 = XLSX.utils.aoa_to_sheet(rows1);
  ws1["!cols"] = [{wch:22},{wch:14},{wch:12},{wch:13},{wch:13},{wch:16},{wch:12}];
  XLSX.utils.book_append_sheet(wb, ws1, "Παρουσιολόγιο");

  // ── Sheet 2: Ωράριο vs Πραγματικές ───────────────────────────────────────
  const rows2 = [];
  rows2.push([`ΩΡΑΡΙΟ VS ΠΡΑΓΜΑΤΙΚΕΣ ΩΡΕΣ — ${monthName} ${year}`]);
  rows2.push([]);
  rows2.push(["Υπάλληλος","Τύπος","Αναμεν. Ώρες/Ημέρα","Εργάσιμες Ημέρες","Αναμεν. Σύνολο","Πραγμ. Κανονικές","Πραγμ. Υπερωρίες","Πραγμ. Σύνολο","Διαφορά"]);

  payrolls.forEach(({emp,data}) => {
    const expected = (parseFloat(emp.expectedHoursPerDay)||8) * data.workingDays;
    const actual   = data.regularHours + data.overtimeHours;
    rows2.push([
      `${emp.firstName} ${emp.lastName}`,
      emp.salaryType==="monthly"?"Μισθωτός":emp.salaryType==="hourly"?"Ωρομίσθιος":"Ημερομίσθιος",
      parseFloat(emp.expectedHoursPerDay)||8,
      data.workingDays,
      +expected.toFixed(2),
      +data.regularHours.toFixed(2),
      +data.overtimeHours.toFixed(2),
      +actual.toFixed(2),
      +(actual-expected).toFixed(2),
    ]);
  });

  const ws2 = XLSX.utils.aoa_to_sheet(rows2);
  ws2["!cols"] = [{wch:22},{wch:14},{wch:18},{wch:16},{wch:16},{wch:18},{wch:16},{wch:16},{wch:12}];
  XLSX.utils.book_append_sheet(wb, ws2, "Ωράριο vs Πραγματικές");

  // ── Sheet 3: Μισθοδοσία ───────────────────────────────────────────────────
  const rows3 = [];
  rows3.push([`ΚΑΤΑΣΤΑΣΗ ΜΙΣΘΟΔΟΣΙΑΣ — ${monthName} ${year}`]);
  rows3.push([]);
  rows3.push(["Α/Α","Υπάλληλος","Τύπος Αμοιβής","Βάση Αμοιβής","Κανον. Ώρες","Υπερωρίες","Μικτές Αποδοχές","ΙΚΑ Εργαζ. (€)","ΙΚΑ Εργοδ. (€)","Καθαρές Αποδοχές","Κόστος Εργοδότη"]);

  let totGross=0,totIKAem=0,totIKAer=0,totNet=0,totCost=0;

  payrolls.forEach(({emp,data},i) => {
    const cost = data.grossSalary+data.ikaEmployer;
    totGross+=data.grossSalary; totIKAem+=data.ikaEmployee; totIKAer+=data.ikaEmployer; totNet+=data.netSalary; totCost+=cost;
    rows3.push([
      i+1,
      `${emp.firstName} ${emp.lastName}`,
      emp.salaryType==="monthly"?"Μισθωτός":emp.salaryType==="hourly"?"Ωρομίσθιος":"Ημερομίσθιος",
      `${emp.salary||0}€ ${emp.salaryType==="monthly"?"/ μήνα":emp.salaryType==="hourly"?"/ ώρα":"/ ημέρα"}`,
      +data.regularHours.toFixed(2),
      +data.overtimeHours.toFixed(2),
      +data.grossSalary.toFixed(2),
      +data.ikaEmployee.toFixed(2),
      +data.ikaEmployer.toFixed(2),
      +data.netSalary.toFixed(2),
      +cost.toFixed(2),
    ]);
  });

  rows3.push([]);
  rows3.push(["","ΣΥΝΟΛΟ","","","","",+totGross.toFixed(2),+totIKAem.toFixed(2),+totIKAer.toFixed(2),+totNet.toFixed(2),+totCost.toFixed(2)]);

  const ws3 = XLSX.utils.aoa_to_sheet(rows3);
  ws3["!cols"] = [{wch:5},{wch:22},{wch:14},{wch:18},{wch:14},{wch:12},{wch:16},{wch:16},{wch:16},{wch:18},{wch:16}];
  XLSX.utils.book_append_sheet(wb, ws3, "Μισθοδοσία Μήνα");

  XLSX.writeFile(wb, `WorkTrack_${monthName}_${year}.xlsx`);
}

// ─── LINKS TAB ────────────────────────────────────────────────────────────────
function LinksTab({employees}) {
  const [copied,setCopied]=useState(null);
  const base=window.location.href.split("?")[0];
  const copy=emp=>{ navigator.clipboard.writeText(`${base}?emp=${emp.id}`).then(()=>{setCopied(emp.id);setTimeout(()=>setCopied(null),2000);}); };
  const activeEmps = employees.filter(e=>e.status==="active"||!e.status);
  return (
    <div>
      <h2 style={S.pageTitle}>📲 Αποστολή Links σε Υπαλλήλους</h2>
      <p style={S.pageSub}>Κάθε υπάλληλος έχει το δικό του μοναδικό link — στέλνεις εσύ, χρησιμοποιεί αυτός</p>

      {/* Βήματα */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:12,marginBottom:24}}>
        {[
          ["1️⃣","Αντιγραφή Link","Πάτα το κουμπί 📋 για να αντιγράψεις τον σύνδεσμο του υπαλλήλου"],
          ["2️⃣","Αποστολή","Στείλε το μέσω WhatsApp ή SMS στο κινητό του υπαλλήλου"],
          ["3️⃣","Ο υπάλληλος ανοίγει","Ανοίγει τον σύνδεσμο από το κινητό του — δεν χρειάζεται λογαριασμός"],
          ["4️⃣","Καταγραφή","Πατάει ΕΙΣΟΔΟΣ όταν έρθει και ΕΞΟΔΟΣ όταν φύγει"],
        ].map(([n,t,d])=>(
          <div key={n} style={{background:"#fff",borderRadius:12,padding:"16px",boxShadow:"0 1px 3px rgba(0,0,0,0.07)",borderTop:"3px solid #3b82f6"}}>
            <div style={{fontSize:24,marginBottom:8}}>{n}</div>
            <div style={{fontWeight:700,fontSize:14,marginBottom:4}}>{t}</div>
            <div style={{fontSize:13,color:"#64748b"}}>{d}</div>
          </div>
        ))}
      </div>

      <h3 style={S.sectionTitle}>Links Ενεργών Υπαλλήλων ({activeEmps.length})</h3>

      {activeEmps.length===0?<Empty text="Δεν υπάρχουν ενεργοί υπάλληλοι. Προσθέστε πρώτα από την καρτέλα Υπάλληλοι."/>:
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          {activeEmps.map(emp=>{
            const link=`${base}?emp=${emp.id}`;
            const waUrl=`https://wa.me/${(emp.phone||"").replace(/\D/g,"")}?text=${encodeURIComponent("Γεια σου "+emp.firstName+"! Εδώ είναι ο προσωπικός σου σύνδεσμος για το παρουσιολόγιο: "+link)}`;
            return (
              <div key={emp.id} style={{...S.linkCard,flexWrap:"wrap",gap:16}}>
                <div style={{...S.avatar,background:stringToColor(emp.firstName),flexShrink:0,width:48,height:48,fontSize:18}}>{emp.firstName[0]}{emp.lastName[0]}</div>
                <div style={{flex:1,minWidth:200}}>
                  <div style={{fontWeight:700,fontSize:17}}>{emp.firstName} {emp.lastName}</div>
                  {emp.phone&&<div style={{fontSize:13,color:"#64748b",marginTop:2}}>📞 {emp.phone}</div>}
                  <div style={{fontSize:12,color:"#94a3b8",wordBreak:"break-all",marginTop:6,background:"#f8fafc",padding:"6px 10px",borderRadius:6,fontFamily:"monospace"}}>{link}</div>
                </div>
                <div style={{display:"flex",flexDirection:"column",gap:8,flexShrink:0}}>
                  <button style={{...S.btnPrimary,fontSize:14,padding:"10px 20px",minWidth:180}} onClick={()=>copy(emp)}>
                    {copied===emp.id?"✅ Αντιγράφηκε!":"📋 Αντιγραφή Link"}
                  </button>
                  {emp.phone&&(
                    <a href={waUrl} target="_blank" rel="noreferrer"
                      style={{display:"block",padding:"10px 20px",background:"#25d366",color:"#fff",textDecoration:"none",textAlign:"center",borderRadius:8,fontWeight:600,fontSize:14}}>
                      💬 Αποστολή WhatsApp
                    </a>
                  )}
                  {!emp.phone&&<div style={{fontSize:12,color:"#f59e0b",textAlign:"center"}}>⚠️ Χωρίς τηλέφωνο</div>}
                </div>
              </div>
            );
          })}
        </div>}
    </div>
  );
}

// ─── EMPLOYEE VIEW ────────────────────────────────────────────────────────────
function EmployeeView({employeeId,employees,records,persistRecords}) {
  const [tick,setTick]=useState(0);
  useEffect(()=>{ const t=setInterval(()=>setTick(x=>x+1),30000); return()=>clearInterval(t); },[]);
  const emp=employees.find(e=>e.id===employeeId);
  if(!emp) return <div style={S.empWrap}><div style={S.empCard}><div style={{fontSize:48}}>❌</div><h2 style={{color:"#ef4444"}}>Άκυρος σύνδεσμος</h2><p style={{color:"#94a3b8"}}>Επικοινωνήστε με τον διαχειριστή.</p></div></div>;

  if(emp.status==="resigned"||emp.status==="terminated") return (
    <div style={S.empWrap}>
      <div style={S.empCard}>
        <div style={{...S.empAvatar,background:"#94a3b8"}}>{emp.firstName[0]}{emp.lastName[0]}</div>
        <h2 style={S.empName}>{emp.firstName} {emp.lastName}</h2>
        <div style={{marginTop:16,background:"#fef2f2",border:"2px solid #fca5a5",borderRadius:14,padding:"20px 24px",textAlign:"center",width:"100%",boxSizing:"border-box"}}>
          <div style={{fontSize:36,marginBottom:8}}>{emp.status==="resigned"?"📋":"🔒"}</div>
          <div style={{fontWeight:700,fontSize:16,color:"#991b1b",marginBottom:6}}>
            {emp.status==="resigned"?"Έχετε καταχωρήσει παραίτηση":"Η σύμβασή σας έχει λήξει"}
          </div>
          <div style={{fontSize:13,color:"#ef4444"}}>
            {emp.status==="resigned"?`Ημερομηνία: ${emp.resignedAt||"—"}`:  `Ημερομηνία: ${emp.terminatedAt||"—"}`}
          </div>
          {(emp.resignReason||emp.terminateReason)&&<div style={{fontSize:13,color:"#64748b",marginTop:6}}>{emp.resignReason||emp.terminateReason}</div>}
        </div>
        <p style={{fontSize:13,color:"#94a3b8",marginTop:16}}>Επικοινωνήστε με τον διαχειριστή για περισσότερες πληροφορίες.</p>
      </div>
    </div>
  );

  const todayStr=new Date().toDateString();
  const todayRecs=records.filter(r=>r.empId===emp.id&&new Date(r.checkIn).toDateString()===todayStr);
  const activeRec=todayRecs.find(r=>!r.checkOut);
  const checkIn =async()=>{ if(activeRec) return; await persistRecords([...records,{id:genId(),empId:emp.id,checkIn:new Date().toISOString(),checkOut:null}]); };
  const checkOut=async()=>{ if(!activeRec) return; await persistRecords(records.map(r=>r.id===activeRec.id?{...r,checkOut:new Date().toISOString()}:r)); };
  const todayDayIdx=(new Date().getDay()+6)%7;
  const scheduledToday=emp.days.includes(todayDayIdx);
  const curTime=new Date().toLocaleTimeString("el-GR",{hour:"2-digit",minute:"2-digit"});
  const curDate=new Date().toLocaleDateString("el-GR",{weekday:"long",day:"numeric",month:"long"});

  return (
    <div style={S.empWrap}>
      <div style={S.empCard}>
        <div style={{...S.empAvatar,background:stringToColor(emp.firstName)}}>{emp.firstName[0]}{emp.lastName[0]}</div>
        <h2 style={S.empName}>{emp.firstName} {emp.lastName}</h2>
        <p style={{color:"#94a3b8",fontSize:14,margin:"0 0 4px"}}>{curDate}</p>
        <p style={{color:"#3b82f6",fontSize:32,fontWeight:800,margin:"0 0 16px"}}>{curTime}</p>
        {!scheduledToday&&<div style={S.warnBox}>⚠️ Σήμερα δεν είναι προγραμματισμένη εργάσιμη ημέρα</div>}
        <div style={{display:"flex",gap:16,fontSize:13,color:"#64748b",marginBottom:24,flexWrap:"wrap",justifyContent:"center"}}>
          <span>🗓 {emp.days.map(d=>DAYS_GR[d]).join(" · ")}</span>
          <span>⏰ {emp.startTime} – {emp.endTime}</span>
        </div>
        {!activeRec?(
          <button style={S.checkInBtn} onClick={checkIn}><span style={{fontSize:36}}>🟢</span><span>ΕΙΣΟΔΟΣ</span></button>
        ):(
          <div style={{width:"100%",textAlign:"center"}}>
            <div style={{background:"#f0fdf4",borderRadius:12,padding:"16px",marginBottom:8}}>
              <div style={{fontSize:13,color:"#10b981",fontWeight:600,marginBottom:4}}>● Είστε παρών από:</div>
              <div style={{fontSize:28,fontWeight:800}}>{fmtTime(activeRec.checkIn)}</div>
              <div style={{fontSize:14,color:"#64748b",marginTop:4}}>{fmtDur(Date.now()-new Date(activeRec.checkIn))} στο χώρο</div>
            </div>
            <button style={S.checkOutBtn} onClick={checkOut}><span style={{fontSize:36}}>🔴</span><span>ΕΞΟΔΟΣ</span></button>
          </div>
        )}
        {todayRecs.filter(r=>r.checkOut).length>0&&(
          <div style={{width:"100%",marginTop:24}}>
            <h4 style={{fontSize:14,color:"#94a3b8",marginBottom:10,textAlign:"center"}}>Σημερινές Καταχωρήσεις</h4>
            {todayRecs.filter(r=>r.checkOut).map(r=>(
              <div key={r.id} style={{display:"flex",justifyContent:"space-between",padding:"10px 14px",background:"#f8fafc",borderRadius:10,marginBottom:8,fontSize:14}}>
                <span>🟢 {fmtTime(r.checkIn)}</span><span>→</span><span>🔴 {fmtTime(r.checkOut)}</span>
                <span style={{fontWeight:700}}>{fmtDur(new Date(r.checkOut)-new Date(r.checkIn))}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── SHARED UI ────────────────────────────────────────────────────────────────
function Spinner() { return <div style={{width:32,height:32,border:"3px solid #e2e8f0",borderTop:"3px solid #3b82f6",borderRadius:"50%",animation:"spin 0.8s linear infinite"}}/>; }
function SectionLabel({children}) { return <div style={{fontSize:11,fontWeight:700,color:"#94a3b8",letterSpacing:1,textTransform:"uppercase",margin:"16px 0 8px",borderBottom:"1px solid #f1f5f9",paddingBottom:4}}>{children}</div>; }
function Table({cols,children}) {
  return <div style={S.tableWrap}><table style={S.table}><thead><tr style={S.thead}>{cols.map(c=><TH key={c}>{c}</TH>)}</tr></thead><tbody>{children}</tbody></table></div>;
}
function TH({children}) { return <th style={S.th}>{children}</th>; }
function TR({children}) { return <tr style={S.tr}>{children}</tr>; }
function TD({children,style:st}) { return <td style={{...S.td,...st}}>{children}</td>; }
function Empty({text}) { return <div style={S.empty}>{text}</div>; }

// ─── STYLES ───────────────────────────────────────────────────────────────────
const S = {
  center:    {display:"flex",justifyContent:"center",alignItems:"center",height:"100vh"},
  wrap:      {minHeight:"100vh",background:"#f8fafc",fontFamily:"'Segoe UI',system-ui,sans-serif"},
  header:    {background:"#0f172a",padding:"0 24px",display:"flex",alignItems:"center",gap:24,height:58,boxShadow:"0 2px 8px rgba(0,0,0,0.2)",position:"sticky",top:0,zIndex:10},
  hLogo:     {color:"#f1f5f9",fontWeight:800,fontSize:19,whiteSpace:"nowrap"},
  nav:       {display:"flex",gap:4},
  navBtn:    {background:"transparent",border:"none",color:"#94a3b8",padding:"8px 14px",borderRadius:8,cursor:"pointer",fontSize:14,fontWeight:500},
  navActive:  {background:"#1e3a5f",color:"#60a5fa"},
  main:      {maxWidth:1020,margin:"0 auto",padding:"28px 20px"},
  pageTitle: {fontSize:23,fontWeight:800,color:"#0f172a",margin:"0 0 4px"},
  pageSub:   {color:"#94a3b8",fontSize:14,margin:"0 0 24px"},
  sectionTitle:{fontSize:16,fontWeight:700,color:"#334155",margin:"28px 0 12px"},
  statsGrid: {display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(200px,1fr))",gap:16,marginBottom:20},
  statCard:  {background:"#fff",borderRadius:14,padding:"18px 20px",display:"flex",alignItems:"center",gap:16,boxShadow:"0 1px 3px rgba(0,0,0,0.07)"},
  statVal:   {fontSize:22,fontWeight:800},
  statLabel: {fontSize:13,color:"#64748b",marginTop:2},
  tableWrap: {background:"#fff",borderRadius:14,boxShadow:"0 1px 3px rgba(0,0,0,0.07)",overflow:"auto"},
  table:     {width:"100%",borderCollapse:"collapse"},
  thead:     {background:"#f8fafc"},
  th:        {padding:"12px 16px",textAlign:"left",fontSize:12,fontWeight:700,color:"#64748b",whiteSpace:"nowrap",borderBottom:"2px solid #f1f5f9"},
  tr:        {borderTop:"1px solid #f8fafc"},
  td:        {padding:"13px 16px",fontSize:14,color:"#1e293b",verticalAlign:"middle"},
  empty:     {background:"#f8fafc",border:"2px dashed #e2e8f0",borderRadius:14,padding:"40px",textAlign:"center",color:"#94a3b8",fontSize:15},
  greenDot:  {display:"inline-block",width:8,height:8,borderRadius:"50%",background:"#10b981",marginRight:6},
  rowBetween:{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20,flexWrap:"wrap",gap:12},
  formCard:  {background:"#fff",borderRadius:14,padding:24,marginBottom:24,boxShadow:"0 1px 3px rgba(0,0,0,0.07)",border:"1px solid #f1f5f9"},
  formTitle: {fontSize:17,fontWeight:700,color:"#0f172a",marginBottom:4},
  grid2:     {display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,marginBottom:8},
  label:     {display:"block",fontSize:13,fontWeight:600,color:"#475569",marginBottom:6},
  input:     {width:"100%",padding:"9px 12px",border:"1px solid #e2e8f0",borderRadius:8,fontSize:14,outline:"none",boxSizing:"border-box",background:"#f8fafc"},
  dayBtn:    {padding:"7px 12px",border:"2px solid #e2e8f0",borderRadius:8,cursor:"pointer",fontSize:13,fontWeight:600,background:"#f8fafc",color:"#64748b"},
  dayActive: {background:"#3b82f6",borderColor:"#3b82f6",color:"#fff"},
  btnPrimary:{padding:"10px 20px",background:"#3b82f6",color:"#fff",border:"none",borderRadius:8,cursor:"pointer",fontWeight:600,fontSize:14},
  btnSec:    {padding:"10px 20px",background:"#f1f5f9",color:"#334155",border:"1px solid #e2e8f0",borderRadius:8,cursor:"pointer",fontWeight:600,fontSize:14},
  filterBtn:    {padding:"6px 14px",border:"1px solid #e2e8f0",borderRadius:20,cursor:"pointer",fontSize:13,fontWeight:500,background:"#f8fafc",color:"#64748b"},
  filterBtnActive:{padding:"6px 14px",border:"1px solid #3b82f6",borderRadius:20,cursor:"pointer",fontSize:13,fontWeight:600,background:"#eff6ff",color:"#1d4ed8"},
  statusBadge:  {fontSize:12,padding:"3px 10px",borderRadius:20,fontWeight:600,whiteSpace:"nowrap"},
  actionBtn:    {background:"none",border:"none",cursor:"pointer",fontSize:18,padding:"4px 6px",borderRadius:6,lineHeight:1},
  avatar:    {width:36,height:36,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontWeight:700,fontSize:13},
  badge:     {fontSize:11,background:"#dcfce7",color:"#15803d",padding:"3px 8px",borderRadius:20,fontWeight:600},
  infoBox:   {background:"#eff6ff",border:"1px solid #bfdbfe",borderRadius:12,padding:"13px 18px",marginBottom:20,fontSize:14,color:"#1d4ed8",lineHeight:1.6},
  linkCard:  {background:"#fff",borderRadius:14,padding:"18px 20px",display:"flex",alignItems:"center",gap:16,boxShadow:"0 1px 3px rgba(0,0,0,0.07)",border:"1px solid #f1f5f9"},
  btnWa:     {background:"#25d366"},
  pinWrap:   {minHeight:"100vh",background:"#0f172a",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Segoe UI',sans-serif"},
  pinCard:   {background:"#1e293b",borderRadius:20,padding:"48px 40px",width:340,textAlign:"center",boxShadow:"0 25px 50px rgba(0,0,0,0.5)"},
  pinTitle:  {color:"#f1f5f9",fontSize:26,fontWeight:800,margin:"0 0 4px"},
  pinSub:    {color:"#94a3b8",marginBottom:32,fontSize:14},
  pinInput:  {width:"100%",padding:"13px 16px",background:"#0f172a",border:"2px solid #334155",borderRadius:10,color:"#f1f5f9",fontSize:18,textAlign:"center",letterSpacing:8,outline:"none",boxSizing:"border-box",marginBottom:8},
  pinBtn:    {width:"100%",padding:"13px",background:"#3b82f6",color:"#fff",border:"none",borderRadius:10,fontSize:16,fontWeight:700,cursor:"pointer",letterSpacing:2,marginTop:8},
  empWrap:   {minHeight:"100vh",background:"linear-gradient(135deg,#0f172a,#1e3a5f)",display:"flex",alignItems:"center",justifyContent:"center",padding:16,fontFamily:"'Segoe UI',sans-serif"},
  empCard:   {background:"#fff",borderRadius:24,padding:"36px 28px",width:"100%",maxWidth:400,textAlign:"center",boxShadow:"0 30px 60px rgba(0,0,0,0.4)",display:"flex",flexDirection:"column",alignItems:"center"},
  empAvatar: {width:72,height:72,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontWeight:800,fontSize:26,marginBottom:16},
  empName:   {fontSize:24,fontWeight:800,color:"#0f172a",margin:"0 0 4px"},
  warnBox:   {background:"#fef3c7",color:"#92400e",borderRadius:10,padding:"10px 16px",fontSize:13,fontWeight:500,marginBottom:16,width:"100%",boxSizing:"border-box"},
  checkInBtn:{display:"flex",flexDirection:"column",alignItems:"center",gap:8,width:"100%",padding:"22px",background:"#f0fdf4",border:"3px solid #22c55e",borderRadius:16,cursor:"pointer",fontSize:20,fontWeight:800,color:"#15803d"},
  checkOutBtn:{display:"flex",flexDirection:"column",alignItems:"center",gap:8,width:"100%",padding:"22px",background:"#fef2f2",border:"3px solid #ef4444",borderRadius:16,cursor:"pointer",fontSize:20,fontWeight:800,color:"#b91c1c",marginTop:16},
};
